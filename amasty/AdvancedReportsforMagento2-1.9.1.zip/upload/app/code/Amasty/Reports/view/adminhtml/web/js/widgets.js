define([
    'jquery',
    'uiRegistry',
    'Magento_Ui/js/modal/modal'
], function ($, registry) {

    $.widget('mage.amreportsWidgets', {

    });
    return $.mage.amreportsWidgets;
});